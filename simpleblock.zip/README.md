 Copyright  Daniel Neis <danielneis@gmail.com>

 Modified for use in NZ Moot Workshop by Richard Jones.

 Cloned from newblock.